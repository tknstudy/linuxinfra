#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CONF_FILE="${SCRIPT_DIR}/repo.conf"
RPM_LIST_FILE="${SCRIPT_DIR}/rpm-packages.txt"
PYTHON_LIST_FILE="${SCRIPT_DIR}/python-rpms.txt"
SQUID_LIST_FILE="${SCRIPT_DIR}/squid-rpms.txt"
IMAGE_LIST_FILE="${SCRIPT_DIR}/docker-images.txt"
LOG_DIR="/var/log/repoinfra"
TS="$(date +%Y%m%d-%H%M%S)"
RUN_DIR="${LOG_DIR}/${TS}"
SUMMARY_FILE="${RUN_DIR}/summary.txt"
DETAIL_FILE="${RUN_DIR}/detail.log"
LATEST_DIR="${LOG_DIR}/latest"

mkdir -p "${RUN_DIR}" "${LATEST_DIR}"
ln -sfn "${RUN_DIR}" "${LATEST_DIR}/current" 2>/dev/null || true

PASS=0
FAIL=0
WARN=0
CURRENT_STAGE=""
CURRENT_STAGE_INDEX=0
CURRENT_STAGE_WEIGHT=0
CURRENT_STAGE_TOTAL=0
CURRENT_STAGE_ITEM=0
CURRENT_STAGE_START=0
WEIGHT_DONE=0
TOTAL_WEIGHT=100
TOTAL_STAGES=6

STAGE_WEIGHTS=(10 10 45 25 5 5)

color() { [[ -t 1 ]] && printf '\033[%sm' "$1" || true; }
C_RESET=$(color 0)
C_GREEN=$(color 32)
C_RED=$(color 31)
C_YELLOW=$(color 33)
C_BLUE=$(color 34)

log_detail() { printf '%s %s\n' "$(date '+%F %T')" "$*" | tee -a "${DETAIL_FILE}" >/dev/null; }
log_summary() { printf '%s\n' "$*" | tee -a "${SUMMARY_FILE}" >/dev/null; }
pass() { PASS=$((PASS+1)); echo "${C_GREEN}[PASS]${C_RESET} $*"; log_detail "PASS: $*"; log_summary "[PASS] $*"; }
fail() { FAIL=$((FAIL+1)); echo "${C_RED}[FAIL]${C_RESET} $*"; log_detail "FAIL: $*"; log_summary "[FAIL] $*"; }
warn() { WARN=$((WARN+1)); echo "${C_YELLOW}[WARN]${C_RESET} $*"; log_detail "WARN: $*"; log_summary "[WARN] $*"; }

require_root() {
  if [[ ${EUID} -ne 0 ]]; then
    echo "Run with sudo/root."
    exit 1
  fi
}

normalize_file() {
  local f="$1"
  if [[ -f "$f" ]] && grep -q $'\r' "$f" 2>/dev/null; then
    sed -i 's/\r$//' "$f"
    log_detail "Normalized line endings: $f"
  fi
}

load_conf() {
  [[ -f "$CONF_FILE" ]] || { echo "Missing $CONF_FILE"; exit 1; }
  normalize_file "$CONF_FILE"
  normalize_file "$RPM_LIST_FILE"
  normalize_file "$PYTHON_LIST_FILE"
  normalize_file "$SQUID_LIST_FILE"
  normalize_file "$IMAGE_LIST_FILE"
  # shellcheck disable=SC1090
  source "$CONF_FILE"
}

human_elapsed() {
  local s=${1:-0} h m
  h=$((s / 3600))
  m=$(((s % 3600) / 60))
  s=$((s % 60))
  printf '%02d:%02d:%02d' "$h" "$m" "$s"
}

stage_begin() {
  CURRENT_STAGE_INDEX="$1"
  CURRENT_STAGE="$2"
  CURRENT_STAGE_WEIGHT="$3"
  CURRENT_STAGE_TOTAL="$4"
  CURRENT_STAGE_ITEM=0
  CURRENT_STAGE_START=$(date +%s)
  echo
  echo "${C_BLUE}==> [${CURRENT_STAGE_INDEX}/${TOTAL_STAGES}] ${CURRENT_STAGE}${C_RESET}"
  log_detail "STAGE START: [${CURRENT_STAGE_INDEX}/${TOTAL_STAGES}] ${CURRENT_STAGE}"
}

stage_progress() {
  local action="$1" item="${2:-}" idx="${3:-0}" total="${4:-0}"
  local stage_pct overall_pct elapsed
  elapsed=$(human_elapsed $(( $(date +%s) - CURRENT_STAGE_START )))
  if [[ "$total" -gt 0 ]]; then
    stage_pct=$(awk -v i="$idx" -v t="$total" 'BEGIN { if (t <= 0) { printf "0.0" } else { printf "%.1f", (i / t) * 100 } }')
  else
    stage_pct="100.0"
  fi
  overall_pct=$(awk -v done="$WEIGHT_DONE" -v sw="$CURRENT_STAGE_WEIGHT" -v sp="$stage_pct" -v tw="$TOTAL_WEIGHT" \
    'BEGIN { printf "%.1f", ((done + (sw * sp / 100.0)) / tw) * 100.0 }')
  printf '%b[%02d/%02d]%b %-28s | Overall: %6s%% | Stage: %6s%% | %s | %s%s\n' \
    "$C_BLUE" "$CURRENT_STAGE_INDEX" "$TOTAL_STAGES" "$C_RESET" \
    "$CURRENT_STAGE" "$overall_pct" "$stage_pct" "$action" "${item:-}" "$elapsed"
}

stage_end() {
  local end elapsed
  end=$(date +%s)
  elapsed=$((end - CURRENT_STAGE_START))
  WEIGHT_DONE=$((WEIGHT_DONE + CURRENT_STAGE_WEIGHT))
  echo "${C_BLUE}<==${C_RESET} ${CURRENT_STAGE} completed in $(human_elapsed "$elapsed")"
  log_detail "STAGE END: [${CURRENT_STAGE_INDEX}/${TOTAL_STAGES}] ${CURRENT_STAGE} ($(human_elapsed "$elapsed"))"
}

count_entries() {
  local file="$1"
  grep -vE '^[[:space:]]*#|^[[:space:]]*$' "$file" 2>/dev/null | wc -l | tr -d ' '
}

append_manifest() {
  local category="$1" package="$2" status="$3"
  printf '%s,%s,%s,%s\n' "$(date '+%F %T')" "$category" "$package" "$status" >> "${MANIFEST_DIR}/cache-manifest.csv"
}

print_header() {
  cat <<EOF2
============================================================
RepoInfra Packager v1.1.0
============================================================
Host          : ${HOSTNAME}
Repo Root     : ${REPO_ROOT}
RPM Cache     : ${RPM_CACHE_DIR}
Image Cache   : ${IMAGE_CACHE_DIR}
Registry      : ${ENABLE_REGISTRY}
Start Time    : $(date '+%F %T')
============================================================
EOF2
}

install_base_tools() {
  stage_begin 1 "Install repo tools" "${STAGE_WEIGHTS[0]}" 1
  stage_progress "Installing repo toolchain" "httpd createrepo_c rsync dnf-plugins-core" 1 1
  if dnf install -y httpd createrepo_c rsync dnf-plugins-core policycoreutils-python-utils curl wget git tar unzip jq lsof bind-utils firewalld chrony openssl ca-certificates vim-enhanced tcpdump socat traceroute nano zip >/dev/null 2>&1; then
    pass "Repo tools" "Installed"
  else
    fail "Repo tools" "Install failed"
  fi
  systemctl enable --now httpd >/dev/null 2>&1 && pass "httpd" "Enabled and started" || warn "httpd" "Could not start"
  stage_end
}

prepare_tree() {
  stage_begin 2 "Prepare repo tree" "${STAGE_WEIGHTS[1]}" 1
  stage_progress "Creating repo directories" "${REPO_ROOT}" 1 1
  mkdir -p "${REPO_ROOT}" "${RPM_CACHE_DIR}" "${IMAGE_CACHE_DIR}" "${MANIFEST_DIR}" \
           "${RPM_CACHE_DIR}/base" "${RPM_CACHE_DIR}/python" "${RPM_CACHE_DIR}/squid"
  mkdir -p "${REPO_HTTP_ROOT}"
  cat > "${REPO_HTTP_ROOT}/index.html" <<HTML
<html><body><h1>RepoInfra</h1><p>Local repository is active.</p></body></html>
HTML
  if command -v semanage >/dev/null 2>&1; then
    semanage fcontext -a -t httpd_sys_content_t "${REPO_ROOT}(/.*)?" 2>/dev/null || true
    restorecon -Rv "${REPO_ROOT}" >/dev/null 2>&1 || true
  fi
  : > "${MANIFEST_DIR}/cache-manifest.csv"
  pass "Repo tree" "Created and published ${REPO_ROOT}"
  stage_end
}

read_manifest_packages() {
  local file="$1" prefix="$2"
  grep -vE '^[[:space:]]*#|^[[:space:]]*$' "$file" 2>/dev/null | sed 's/[[:space:]]\+$//' | while IFS= read -r pkg; do
    [[ -n "$pkg" ]] && printf '%s|%s\n' "$prefix" "$pkg"
  done
}

cache_rpm_packages() {
  stage_begin 3 "Cache RPM packages" "${STAGE_WEIGHTS[2]}" 1
  local pkgdir_base="${RPM_CACHE_DIR}/base"
  local pkgdir_python="${RPM_CACHE_DIR}/python"
  local pkgdir_squid="${RPM_CACHE_DIR}/squid"
  local -a items=()
  local line prefix pkg

  for line in "$(read_manifest_packages "$RPM_LIST_FILE" base)" "$(read_manifest_packages "$PYTHON_LIST_FILE" python)" "$(read_manifest_packages "$SQUID_LIST_FILE" squid)"; do :; done

  while IFS= read -r line; do [[ -n "$line" ]] && items+=("$line"); done < <(read_manifest_packages "$RPM_LIST_FILE" base)
  while IFS= read -r line; do [[ -n "$line" ]] && items+=("$line"); done < <(read_manifest_packages "$PYTHON_LIST_FILE" python)
  while IFS= read -r line; do [[ -n "$line" ]] && items+=("$line"); done < <(read_manifest_packages "$SQUID_LIST_FILE" squid)

  if [[ ${#items[@]} -eq 0 ]]; then
    warn "RPM list" "No package entries found"
    stage_end
    return 0
  fi

  if ! command -v dnf >/dev/null 2>&1; then
    fail "DNF" "dnf not found"
    stage_end
    return 1
  fi
  if ! dnf download --help >/dev/null 2>&1; then
    fail "dnf download" "dnf-plugins-core missing or download unavailable"
    stage_end
    return 1
  fi

  local total=${#items[@]} idx=0 destdir safe_status
  for line in "${items[@]}"; do
    idx=$((idx + 1))
    prefix=${line%%|*}
    pkg=${line#*|}
    case "$prefix" in
      base) destdir="$pkgdir_base" ;;
      python) destdir="$pkgdir_python" ;;
      squid) destdir="$pkgdir_squid" ;;
      *) destdir="$pkgdir_base" ;;
    esac
    stage_progress "Downloading package" "$pkg" "$idx" "$total"
    if dnf download --destdir "$destdir" --resolve "$pkg" >/dev/null 2>&1; then
      pass "RPM ${pkg}" "cached in ${prefix}"
      append_manifest "rpm:${prefix}" "$pkg" "cached"
    else
      warn "RPM ${pkg}" "not downloaded (possibly unavailable in current repos)"
      append_manifest "rpm:${prefix}" "$pkg" "warn"
    fi
  done

  for destdir in "$pkgdir_base" "$pkgdir_python" "$pkgdir_squid"; do
    if compgen -G "${destdir}/*.rpm" >/dev/null; then
      createrepo_c "$destdir" >/dev/null 2>&1 || warn "createrepo_c" "metadata generation failed for ${destdir}"
    fi
  done

  pass "RPM cache" "Stored under ${RPM_CACHE_DIR}"
  stage_end
}

cache_docker_images() {
  stage_begin 4 "Cache container images" "${STAGE_WEIGHTS[3]}" 1
  if [[ ! -s "$IMAGE_LIST_FILE" ]]; then
    warn "Image list" "No docker image list found; skipping image cache"
    stage_end
    return 0
  fi
  if ! command -v docker >/dev/null 2>&1; then
    warn "Docker" "Docker not installed; image cache skipped"
    stage_end
    return 0
  fi

  mapfile -t imgs < <(grep -vE '^[[:space:]]*#|^[[:space:]]*$' "$IMAGE_LIST_FILE" | sed 's/[[:space:]]\+$//')
  if [[ ${#imgs[@]} -eq 0 ]]; then
    warn "Image list" "Image list is empty"
    stage_end
    return 0
  fi

  local total=${#imgs[@]} idx=0 img safe_name tar_file
  for img in "${imgs[@]}"; do
    idx=$((idx + 1))
    stage_progress "Downloading image" "$img" "$idx" "$total"
    if docker pull "$img" >/dev/null 2>&1; then
      safe_name="$(echo "$img" | sed 's#/#_#g; s#:#_#g')"
      tar_file="${IMAGE_CACHE_DIR}/${safe_name}.tar"
      docker save -o "$tar_file" "$img" >/dev/null 2>&1 || warn "docker save ${img}" "save failed"
      pass "Image ${img}" "cached to ${tar_file}"
      append_manifest "image" "$img" "cached"
    else
      warn "Image ${img}" "pull failed"
      append_manifest "image" "$img" "warn"
    fi
  done

  pass "Image cache" "Completed"
  stage_end
}

configure_registry() {
  stage_begin 5 "Configure registry" "${STAGE_WEIGHTS[4]}" 1
  if [[ "${ENABLE_REGISTRY}" != "yes" ]]; then
    warn "Registry" "Disabled in config"
    stage_end
    return 0
  fi

  if ! command -v docker >/dev/null 2>&1; then
    warn "Registry" "Docker not present; registry container skipped"
    stage_end
    return 0
  fi

  stage_progress "Starting local registry" "${REGISTRY_NAME}" 1 1
  mkdir -p /var/lib/registry
  if docker ps -a --format '{{.Names}}' | grep -qx "${REGISTRY_NAME}"; then
    docker rm -f "${REGISTRY_NAME}" >/dev/null 2>&1 || true
  fi

  if docker pull registry:2 >/dev/null 2>&1; then
    if docker run -d --restart=always --name "${REGISTRY_NAME}" -p "${REGISTRY_PORT}:5000" -v /var/lib/registry:/var/lib/registry registry:2 >/dev/null 2>&1; then
      pass "Registry" "Container started on port ${REGISTRY_PORT}"
    else
      warn "Registry" "Could not start registry container"
    fi
  else
    warn "Registry image" "registry:2 pull failed"
  fi
  stage_end
}

finalize() {
  stage_begin 6 "Finalize and verify" "${STAGE_WEIGHTS[5]}" 1
  stage_progress "Collecting cache metrics" "${REPO_ROOT}" 1 1
  local rpm_count image_count rpm_size img_size
  rpm_count=$(find "${RPM_CACHE_DIR}" -type f -name '*.rpm' 2>/dev/null | wc -l | tr -d ' ')
  image_count=$(find "${IMAGE_CACHE_DIR}" -type f -name '*.tar' 2>/dev/null | wc -l | tr -d ' ')
  rpm_size=$(du -sh "${RPM_CACHE_DIR}" 2>/dev/null | awk '{print $1}')
  img_size=$(du -sh "${IMAGE_CACHE_DIR}" 2>/dev/null | awk '{print $1}')

  {
    echo
    echo "============================================================"
    echo "RepoInfra Summary"
    echo "============================================================"
    echo "RPM packages cached  : ${rpm_count:-0}"
    echo "Docker images cached : ${image_count:-0}"
    echo "RPM cache size       : ${rpm_size:-unknown}"
    echo "Image cache size     : ${img_size:-unknown}"
    echo "Repo root            : ${REPO_ROOT}"
    echo "HTTP root            : ${REPO_HTTP_ROOT}"
    echo "Registry              : ${ENABLE_REGISTRY}"
    echo "Pass                 : ${PASS}"
    echo "Warn                 : ${WARN}"
    echo "Fail                 : ${FAIL}"
    echo "Run                  : ${RUN_DIR}"
    echo "============================================================"
  } | tee -a "$SUMMARY_FILE" >/dev/null

  cp -f "$SUMMARY_FILE" "$LATEST_DIR/summary.txt" 2>/dev/null || true
  cp -f "$DETAIL_FILE" "$LATEST_DIR/detail.txt" 2>/dev/null || true
  echo
  echo "Summary: ${SUMMARY_FILE}"
  echo "Detail : ${DETAIL_FILE}"
  stage_end
}

main() {
  require_root
  load_conf
  print_header
  install_base_tools
  prepare_tree
  cache_rpm_packages
  cache_docker_images
  configure_registry
  finalize

  if [[ ${FAIL} -gt 0 ]]; then
    exit 1
  fi
}

main "$@"
