#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CONF_FILE="${SCRIPT_DIR}/repo.conf"

if [[ -f "${CONF_FILE}" && -n "$(grep -n $'\r' "${CONF_FILE}" 2>/dev/null || true)" ]]; then
  sed -i 's/\r$//' "${CONF_FILE}"
fi

# shellcheck disable=SC1090
source "${CONF_FILE}"

PASS=0
FAIL=0
WARN=0

color() { [[ -t 1 ]] && printf '\033[%sm' "$1" || true; }
C_RESET=$(color 0)
C_GREEN=$(color 32)
C_RED=$(color 31)
C_YELLOW=$(color 33)
C_BLUE=$(color 34)

log() { printf '%s\n' "$*"; }
pass() { PASS=$((PASS+1)); log "${C_GREEN}[PASS]${C_RESET} $*"; }
fail() { FAIL=$((FAIL+1)); log "${C_RED}[FAIL]${C_RESET} $*"; }
warn() { WARN=$((WARN+1)); log "${C_YELLOW}[WARN]${C_RESET} $*"; }

require_root() {
  if [[ ${EUID} -ne 0 ]]; then
    echo "Run with sudo/root."
    exit 1
  fi
}

section() {
  log
  log "${C_BLUE}==> ${1}${C_RESET}"
}

check_dir() {
  local label="$1" path="$2"
  [[ -d "$path" ]] && pass "${label} exists: ${path}" || fail "${label} missing: ${path}"
}

check_file() {
  local label="$1" path="$2"
  [[ -f "$path" ]] && pass "${label} exists: ${path}" || fail "${label} missing: ${path}"
}

check_cmd() {
  local label="$1" cmd="$2"
  if command -v "$cmd" >/dev/null 2>&1; then
    pass "${label} available"
  else
    fail "${label} missing"
  fi
}

check_httpd() {
  if systemctl is-active --quiet httpd; then
    pass "httpd active"
  else
    fail "httpd inactive"
  fi
}

check_registry() {
  if [[ "${ENABLE_REGISTRY}" == "yes" ]]; then
    if systemctl is-active --quiet docker; then
      pass "Docker active for registry"
    else
      fail "Docker inactive for registry"
    fi
    if curl -fsS "http://127.0.0.1:${REGISTRY_PORT}/v2/" >/dev/null 2>&1; then
      pass "Registry API reachable"
    else
      warn "Registry API not reachable"
    fi
  else
    warn "Registry disabled in config"
  fi
}

check_metadata() {
  local d
  local found=0
  while IFS= read -r d; do
    [[ -n "$d" ]] || continue
    if find "$d" -maxdepth 1 -type d -name 'repodata' >/dev/null 2>&1 && find "$d" -maxdepth 1 -type d -name 'repodata' | grep -q .; then
      pass "Repo metadata present: ${d}"
      found=1
    else
      warn "Repo metadata missing in: ${d}"
    fi
  done < <(find "${RPM_CACHE_DIR}" -mindepth 1 -maxdepth 1 -type d 2>/dev/null)
  [[ $found -eq 1 ]] || warn "No repodata directories found yet"
}

check_counts() {
  local rpm_count img_count rpm_size img_size
  rpm_count=$(find "${RPM_CACHE_DIR}" -type f -name '*.rpm' 2>/dev/null | wc -l | tr -d ' ')
  img_count=$(find "${IMAGE_CACHE_DIR}" -type f -name '*.tar' 2>/dev/null | wc -l | tr -d ' ')
  rpm_size=$(du -sh "${RPM_CACHE_DIR}" 2>/dev/null | awk '{print $1}' || true)
  img_size=$(du -sh "${IMAGE_CACHE_DIR}" 2>/dev/null | awk '{print $1}' || true)
  pass "Cached RPM count" "${rpm_count:-0}"
  pass "Cached image count" "${img_count:-0}"
  log "RPM cache size: ${rpm_size:-unknown}"
  log "Image cache size: ${img_size:-unknown}"
}

main() {
  require_root
  section "RepoInfra verification"
  log "Host: ${HOSTNAME}"
  log "Repo root: ${REPO_ROOT}"
  log "RPM cache: ${RPM_CACHE_DIR}"
  log "Image cache: ${IMAGE_CACHE_DIR}"

  hostname_ok="$(hostname -f 2>/dev/null || hostname || true)"
  [[ "${hostname_ok}" == "${HOSTNAME}" ]] && pass "Hostname matches" || fail "Hostname mismatch: ${hostname_ok}"

  check_dir "Repo root" "${REPO_ROOT}"
  check_dir "RPM cache" "${RPM_CACHE_DIR}"
  check_dir "Image cache" "${IMAGE_CACHE_DIR}"
  check_dir "Manifest dir" "${MANIFEST_DIR}"
  check_file "Repo index" "${REPO_HTTP_ROOT}/index.html"
  check_httpd
  check_cmd "createrepo_c" createrepo_c
  check_cmd "rsync" rsync
  check_counts
  check_metadata
  check_registry

  log
  log "PASS=${PASS} WARN=${WARN} FAIL=${FAIL}"
  [[ ${FAIL} -eq 0 ]]
}

main "$@"
