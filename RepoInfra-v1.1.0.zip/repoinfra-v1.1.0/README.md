# RepoInfra v1.1.0

RepoInfra prepares a Rocky Linux 9.7 VM as a local software distribution server.
It is designed to sit on top of a base LinuxInfra build.

## What it does

- Installs repo tooling
- Creates a local RPM cache
- Caches Python support packages
- Caches Squid / proxy packages
- Builds repository metadata with createrepo_c
- Downloads and saves container images
- Optionally starts a local container registry
- Serves the repo tree over HTTP
- Writes summary and detailed logs
- Shows progress with stage and percentage updates

## What to run

```bash
cd /home/demo/RepoInfra
chmod +x *.sh
sudo ./RepoInfra.sh
```

## Recommended directory layout

- /srv/repo/rpms
- /srv/repo/images
- /srv/repo/manifests
- /var/www/html/repo

## Starter package lists

- `rpm-packages.txt` - base repo packages
- `python-rpms.txt` - Python support packages
- `squid-rpms.txt` - packages to cache for the proxy VM
- `docker-images.txt` - container images to cache

## Notes

RepoInfra v1.1.0 shows lightweight progress feedback during long runs so you can see what it is doing without reading full package-manager output.
