\
#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CONFIG_FILE="${SCRIPT_DIR}/infra.conf"
HOSTS_FILE="${SCRIPT_DIR}/hosts.csv"
ENGINE_FILE="${SCRIPT_DIR}/linuxinfra_engine.sh"

normalize_text_file() {
  local file="$1"
  local label="$2"
  if [[ -f "$file" ]] && grep -q $'\r' "$file" 2>/dev/null; then
    printf 'Normalizing Windows line endings in %s\n' "$label"
    if command -v dos2unix >/dev/null 2>&1; then
      dos2unix -q "$file"
    else
      sed -i 's/\r$//' "$file"
    fi
  fi
}

load_host_preview() {
  local role="$1"
  awk -F'|' -v role="$role" '
    $0 !~ /^#/ && NF >= 8 && $1 == role {
      gsub(/^[[:space:]]+|[[:space:]]+$/, "", $2)
      gsub(/^[[:space:]]+|[[:space:]]+$/, "", $3)
      gsub(/^[[:space:]]+|[[:space:]]+$/, "", $4)
      gsub(/^[[:space:]]+|[[:space:]]+$/, "", $5)
      gsub(/^[[:space:]]+|[[:space:]]+$/, "", $7)
      printf "%s|%s|%s|%s|%s\n", $2, $3, $4, $5, $7
      exit
    }
  ' "$HOSTS_FILE"
}

show_banner() {
  printf '\n========================================================\n'
  printf '           LinuxInfra Deployment Framework\n'
  printf '                   Version %s\n' "${PROJECT_VERSION:-0.7.0}"
  printf '========================================================\n\n'
}

show_role_preview() {
  local role="$1"
  local preview
  preview="$(load_host_preview "$role" || true)"
  if [[ -z "$preview" ]]; then
    echo "No host preview found for role: $role"
    return 1
  fi
  IFS='|' read -r hostname ip gateway iface label <<< "$preview"
  printf 'Role           : %s\n' "$role"
  printf 'Hostname       : %s\n' "$hostname"
  printf 'IP/CIDR        : %s\n' "$ip"
  printf 'Gateway        : %s\n' "$gateway"
  printf 'Interface      : %s\n' "$iface"
  printf 'Host label     : %s\n' "$label"
  case "$role" in
    siem)
      printf 'Firewall       : SIEM + DNS policy\n'
      printf 'DNS assets     : will be prepared\n'
      ;;
    internal)
      printf 'Firewall       : mail policy\n'
      printf 'Mail role      : internal server\n'
      ;;
    external)
      printf 'Firewall       : mail policy\n'
      printf 'Mail role      : external server\n'
      ;;
  esac
  printf 'Timezone       : %s\n' "${TIMEZONE:-Asia/Kolkata}"
  printf 'NTP            : %s\n' "${NTP_SERVER:-time.google.com}"
}

prompt_role() {
  local choice
  while true; do
    show_banner
    printf 'Select Server Role\n\n'
    printf '1) SIEM + DNS\n'
    printf '2) Internal Mail Server\n'
    printf '3) External Mail Server\n'
    printf '4) Dry Run / Validate Only\n'
    printf '5) Exit\n\n'
    read -r -p 'Enter choice [1-5]: ' choice
    case "$choice" in
      1) ROLE="siem"; MODE="build"; break ;;
      2) ROLE="internal"; MODE="build"; break ;;
      3) ROLE="external"; MODE="build"; break ;;
      4)
        show_banner
        printf 'Dry Run Role Selection\n\n'
        printf '1) SIEM + DNS\n'
        printf '2) Internal Mail Server\n'
        printf '3) External Mail Server\n\n'
        read -r -p 'Enter dry-run role [1-3]: ' choice
        case "$choice" in
          1) ROLE="siem" ;;
          2) ROLE="internal" ;;
          3) ROLE="external" ;;
          *) echo 'Invalid dry-run role'; continue ;;
        esac
        MODE="dry-run"
        break
        ;;
      5) exit 0 ;;
      *) echo 'Invalid choice. Try again.' ; sleep 1 ;;
    esac
  done
}

main() {
  if [[ ${EUID} -ne 0 ]]; then
    echo "ERROR: Run this script as root: sudo ./LinuxInfra.sh" >&2
    exit 2
  fi

  if [[ ! -r "$CONFIG_FILE" || ! -r "$HOSTS_FILE" || ! -x "$ENGINE_FILE" ]]; then
    echo "ERROR: infra.conf, hosts.csv, and linuxinfra_engine.sh must exist beside this script." >&2
    exit 2
  fi

  normalize_text_file "$CONFIG_FILE" "infra.conf"
  normalize_text_file "$HOSTS_FILE" "hosts.csv"

  # shellcheck source=/dev/null
  source "$CONFIG_FILE"

  prompt_role

  show_banner
  echo "Selected Role Summary"
  echo
  show_role_preview "$ROLE"
  echo
  if [[ "$MODE" == "dry-run" ]]; then
    echo 'Mode           : DRY RUN / VALIDATE ONLY'
  else
    echo 'Mode           : BUILD'
  fi
  echo
  read -r -p 'Proceed with this server build? [y/N]: ' answer
  case "${answer,,}" in
    y|yes) ;;
    *) echo 'Cancelled.'; exit 0 ;;
  esac

  exec "$ENGINE_FILE" "$ROLE" "$MODE"
}

main "$@"
