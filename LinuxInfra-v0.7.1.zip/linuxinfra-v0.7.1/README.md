# LinuxInfra v0.7.1

This package is meant to be copied into a working directory such as:

```bash
/home/demo/LinuxInfra
```

## What changed in v0.7.1

- Introduced a single interactive launcher: `LinuxInfra.sh`
- The launcher prompts for the role before running the engine
- Added a dry-run / validate-only path
- Kept the shared engine in `linuxinfra_engine.sh`
- Preserved automatic Linux line-ending normalization for `infra.conf` and `hosts.csv`
- Kept the summary and detailed logs

## Files

- `LinuxInfra.sh` — interactive menu and role selection
- `linuxinfra_engine.sh` — shared build engine
- `infra.conf` — shared build configuration
- `hosts.csv` — role inventory

## Host inventory

- `siem.log.local` -> `192.168.10.8/24`
- `mail1.internal.local` -> `192.168.10.11/24`
- `mail2.external.local` -> `192.168.10.12/24`

All hosts use:

- Gateway: `192.168.10.1`
- Primary DNS: `192.168.10.8`
- Secondary DNS: `172.16.1.10`
- NTP: `time.google.com`
- Timezone: `Asia/Kolkata`
- Interface: `ens192`

## Run

Copy the folder to `/home/demo/LinuxInfra`, then:

```bash
cd /home/demo/LinuxInfra
chmod +x *.sh
sudo ./LinuxInfra.sh
```

## Role options

1. SIEM + DNS
2. Internal Mail Server
3. External Mail Server
4. Dry Run / Validate Only
5. Exit

## Output

Each run creates:

- `status_summary.txt`
- `detailed_debug.log`

Permanent copies are archived in:

- `/var/log/linuxinfra/`

## Notes

- The first network-changing build should ideally be run from the VM console, not over SSH.
- The progress percentages are display estimates, not exact command-completion percentages.
- The SIEM role prepares DNS generator assets under `/opt/linuxinfra/dns/` but does not start BIND automatically.


## v0.7.1 fix

- Preloads the host record once in the engine so TARGET_* values remain available across all stages.
- Added a standalone verify.sh for post-build checks.
