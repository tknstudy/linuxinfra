# Validation notes

## Rejected releases

### 1.0.0

Release blockers included a non-functional generated rollback script, no
backup for overwritten RPMs, warning-only HTTP failures, release-source
selection that could mismatch the existing Git version, an incomplete Mailcow
prerequisite list, and insufficient signature/closure gates.

### 1.1.0 archive

The archive produced during the first correction pass did not contain every
hardened runtime change that had subsequently been reviewed and tested. It is
therefore superseded and must not be used.

## 1.1.1 validation scope

Static checks:

- archive path and member-type safety
- package SHA-256 self-check
- Bash syntax for every shell script
- required-file and version-invariant checks
- documentation/code consistency review
- command and configuration review against official Mailcow, DNF, Rocky, and
  SELinux sources

Mocked runtime checks:

- successful full build and publication
- manual rollback after success
- automatic rollback after failed HTTP publication
- automatic rollback after failure during first repository metadata build
- failure before publication when a source package is unavailable
- dry-run isolation from repository, Apache, firewall, and HTTP publication
- rejection of an unsafe Git downgrade
- restoration of prior HTTPD active/enabled state
- signing-key fingerprint mismatch rejection
- unsafe repository path configuration rejection
- accurate dry-run no-rollback status
- client repository trust-anchor generation
- repoclosure failure with a specific pre-publication diagnosis
- Apache syntax failure with automatic rollback

## Live acceptance boundary

The packaging environment is not the Rocky 9 Repo VM. Real DNF dependency
solving, package downloads, RPM signatures, SELinux policy, firewalld, Apache,
and Repo VM network reachability are validated by the package itself during
the first controlled Repo VM run. The package is designed to stop before
publication for any source, key, signature, or repoclosure failure and to roll
back automatically for a later publication failure.
