# Validation record for 1.1.1

Release decision: **approved for a controlled first run on the Rocky 9 Repo
VM**, after the included package self-check and dry run.

The package has passed static integrity and syntax checks plus mocked success,
failure, dry-run, version-alignment, fingerprint, HTTP, service-state, and
rollback control-flow tests. See `VALIDATION-NOTES.md` and the external release
validation report distributed with the archive.

A live Repo VM run remains the acceptance test for real Rocky DNF content, RPM
signatures, SELinux, firewalld, Apache, and network behavior.
