# Engineering sources

The design was checked against primary project documentation and official
repositories:

- Mailcow installation prerequisites:
  https://docs.mailcow.email/getstarted/install/
- DNF download plugin (`--resolve`, `--alldeps`):
  https://dnf-plugins-core.readthedocs.io/en/latest/download.html
- DNF repoclosure plugin:
  https://dnf-plugins-core.readthedocs.io/en/latest/repoclosure.html
- Rocky Linux 9 signing-key fingerprint:
  https://rockylinux.org/resources/gpg-key-info
- Rocky 9 BaseOS repository and signing key:
  https://dl.rockylinux.org/pub/rocky/9/BaseOS/x86_64/os/
- Rocky 9 AppStream Git packages:
  https://dl.rockylinux.org/pub/rocky/9/AppStream/x86_64/os/Packages/g/
- Rocky 9 AppStream Perl packages:
  https://dl.rockylinux.org/pub/rocky/9/AppStream/x86_64/os/Packages/p/
- SELinux persistent file-context management:
  https://docs.redhat.com/en/documentation/red_hat_enterprise_linux/9/html/using_selinux/
