# Design notes

## Path and execution safety

The runtime rejects non-absolute roots, filesystem-root targets, unsafe `.` or
`..` path components, and repository or manifest targets outside their
configured parent roots before creating or deleting content. It also sets the
`C` locale so DNF, RPM, and text parsing are deterministic.

## Exact Git alignment

The repair first inspects `git` RPMs already present below `/srv/repo/rpms`.
It targets the highest existing version-release and requires the isolated Rocky
source to provide the same version of `git`, `git-core`, `git-core-doc`, and
`perl-Git`. This prevents an older vault closure from being published beside a
newer, still-broken best candidate.

## Source isolation

A run-scoped DNF configuration enables only official Rocky 9 BaseOS,
AppStream, and CRB. Existing LinuxInfra or third-party repositories cannot
silently satisfy the repair transaction.

## Complete dependency closure

The package uses `dnf download --resolve --alldeps`. `--alldeps` is required
because the Repo VM may already have dependencies installed; without it, those
RPMs can be omitted from an offline repository.

## Trust validation

The Rocky 9 signing key is downloaded from the selected Rocky source. Its full
fingerprint is compared with the published Rocky 9 release-key fingerprint.
The key is then imported into a run-scoped RPM database, and every staged RPM
must pass `rpm -K` verification. The generated Rocky 9 client repository uses
`file:///etc/pki/rpm-gpg/RPM-GPG-KEY-Rocky-9` as its trust anchor; a verified
HTTP copy is published for audit and recovery, not for first-use trust.

## Pre-publication gate

No repository RPM is changed until all of these pass:

- exact Git component availability
- full dependency download
- signing-key fingerprint verification
- every staged RPM signature
- required-package presence
- matching Git component versions
- local-only full staged-repository repoclosure

## Transaction and rollback

New files and replaced files are recorded separately. Replaced files and
existing `repodata` are backed up before mutation. If any post-publication
phase fails, automatic rollback removes only new files and restores replaced
files, metadata, Apache configuration, SELinux/firewall changes, and HTTPD
state. A manual rollback script remains after success.

## File permissions

The package uses `umask 022`, creates managed directories normally, and
publishes RPMs and the key with mode `0644`. It deliberately avoids a blanket
recursive `chmod` over unrelated existing content. The local HTTP checks are
the final proof that Apache can read the published content.

## HTTP and SELinux

The package applies a persistent `httpd_sys_content_t` mapping for
`/srv/repo`, manages aliases for `/rpms`, `/images`, and `/manifests`, validates
Apache syntax, restores prior service state on rollback, and treats a failed
local HTTP resource check as a build failure.
