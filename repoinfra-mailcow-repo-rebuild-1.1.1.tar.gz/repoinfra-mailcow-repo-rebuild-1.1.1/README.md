# RepoInfra Mailcow Repository Rebuild 1.1.1

This package repairs and rebuilds the Rocky Linux host-prerequisite RPM
repository used by the Mailcow lab. It is designed for the specific failure in
which `git-2.52.0-1.el9` is visible to `mail1`, but its exact companion RPMs and
dependency closure are absent.

## Release status

Version 1.1.1 supersedes 1.0.0 and the unpublished 1.1.0 validation candidate.
Do not run either earlier archive.

The package fails before publication unless the selected Rocky source provides
an exact coherent set of:

- `git`
- `git-core`
- `git-core-doc`
- `perl-Git`

For the current lab repository, the expected version-release is
`2.52.0-1.el9`.

## What the package does

1. Requires root, validates configured path hierarchies, acquires an exclusive
   run lock, checks Rocky/EL9 x86_64, and checks free space.
2. Creates isolated Rocky BaseOS, AppStream, and CRB source definitions. It
   does not use `linuxinfra-base` as a source for the repair.
3. Examines existing `git` RPMs under `/srv/repo/rpms` and aligns to the highest
   version already published.
4. Confirms that the source contains exact matching Git split packages.
5. Loads the current Mailcow host prerequisites: `git`, `openssl`, `curl`,
   `gawk`, `coreutils`, `grep`, `jq`, and `ca-certificates`.
6. Downloads the complete hard-dependency closure with
   `dnf download --resolve --alldeps`.
7. Downloads the Rocky 9 signing key, verifies its full published fingerprint,
   and checks every staged RPM signature in a run-scoped RPM database.
8. Builds temporary metadata and runs local-only `dnf repoclosure` before any
   repository RPM is changed.
9. Publishes atomically to `/srv/repo/rpms/mailcow` and, by default, copies the
   same closure into `/srv/repo/rpms/base` for the existing
   `linuxinfra-base` client configuration.
10. Backs up replaced RPMs, old metadata, and the Apache configuration before
    changing them.
11. Creates managed repository paths and new files with web-readable modes,
    but does not recursively broaden unrelated existing permissions.
12. Applies a persistent SELinux `httpd_sys_content_t` mapping for
    `/srv/repo`, validates Apache, manages HTTP firewall access when firewalld
    is active, and requires local HTTP publication checks to pass.
13. Generates detailed logs, manifests, checksums, a client `.repo` file with
    `gpgcheck=1` and Rocky 9's OS-provided release key as the trust anchor, and
    a run-specific rollback package.
14. Automatically executes rollback if a failure occurs after publication has
    started. The rollback script remains available for an operator-requested
    reversal after a successful run.

## Package self-check

Run this immediately after extraction:

```bash
bash ./bin/package-self-check.sh
```

It verifies the exact packaged file inventory, all packaged SHA-256 checksums,
member types, Unix line endings, executable shell syntax, required files,
version consistency, and key safety invariants.

## Dry run on the Repo VM

```bash
sudo bash ./run.sh --dry-run
```

Dry run downloads, verifies signatures, checks the exact Git set, and runs
repoclosure, but does not publish RPMs or modify SELinux, Apache, firewalld, or
repository metadata. It may install missing Repo VM build tools from the
isolated Rocky source.

## Build and publish on the Repo VM

```bash
sudo bash ./run.sh
```

For the current failure, an explicit equivalent run is:

```bash
sudo bash ./run.sh --release 9 --git-version 2.52.0-1.el9
```

Do not select an older Rocky vault unless it contains the exact existing Git
version. The package rejects a mismatch before publication.

## Important options

```text
--dry-run                  Validate staging without publication.
--release 9                Current Rocky 9 stream; default.
--release 9.8              Explicit Rocky 9.8 vault.
--git-version VERSION      Exact version-release to repair.
--no-compat                Skip merge into /srv/repo/rpms/base.
--no-apache                Preserve the current Apache alias file.
--keep-staging             Keep staged RPMs after success.
--force-platform           Unsupported platform override.
```

## Logs and status

Every run creates:

```text
/var/log/repoinfra/mailcow-repo-rebuild/<run-id>/
```

Important files include:

```text
detail.log
summary.txt
report.txt
source-packages.tsv
git-source-set.tsv
package-manifest.tsv
SHA256SUMS
repoclosure.txt
linuxinfra-mailcow.repo
new-files.txt
replaced-files.tsv
metadata-state.tsv
rollback.sh
rollback.env
```

The terminal shows each phase, what is being attempted, PASS/WARN/FAIL status,
elapsed time, source selection, target Git version, key fingerprint, publication
checks, and rollback status.

## Validate from mail1

After the Repo VM reports overall PASS:

```bash
sudo dnf clean all
sudo dnf makecache
sudo dnf install -y git
```

A deeper client-side check is included:

```bash
sudo bash ./bin/mailcow-client-check.sh
sudo bash ./bin/mailcow-client-check.sh --install
```

## Rollback

If a post-publication phase fails, rollback runs automatically. To reverse a
successful run manually:

```bash
sudo bash /var/log/repoinfra/mailcow-repo-rebuild/<run-id>/rollback.sh
```

Rollback removes only files introduced by that run, restores overwritten RPMs,
restores prior repository metadata and Apache configuration, removes SELinux or
firewall changes made by the run, and restores the prior HTTPD active/enabled
state.

## Scope

This package builds the Rocky/RHEL host-prerequisite RPM closure. Docker CE
RPMs, Docker Compose, Mailcow source, container images, image archives, and
Mailcow application manifests remain part of the separate Mailcow annex
workflow.
