# Changelog

## 1.1.1

- Rebuilt the distributed archive from the hardened runtime implementation;
  the earlier 1.1.0 archive did not contain all reviewed runtime corrections.
- Added full Rocky 9 signing-key fingerprint validation against
  `21CB 256A E16F C54C 6E65 2949 702D 426D 350D 275D`.
- Added automatic rollback for failures after repository publication begins.
- Preserved and restored prior HTTPD active and enabled state during rollback.
- Added safe temporary-file cleanup during atomic RPM publication.
- Made local HTTP failures fatal rather than warning-only.
- Added firewalld state tracking and rollback.
- Added explicit pre-lock `flock` validation.
- Improved client validation to select the best x86_64 Git candidate, require
  exact companion versions, and use a safely created temporary file.
- Corrected documentation so permission and rollback behavior match the code.
- Added locale-stable command parsing and strict repository path hierarchy checks.
- Corrected dry-run rollback status and terminal guidance.
- Changed the generated Rocky 9 client repository to use the OS-provided local
  Rocky release key as its trust anchor; the verified HTTP key remains an audit
  and recovery artifact.
- Expanded the package self-check to reject untracked files, special members,
  non-executable scripts, CRLF content, and missing safety invariants.
- Corrected the repoclosure failure branch so it emits its specific
  pre-publication diagnosis instead of being intercepted by the generic ERR
  trap.

## 1.1.0

- Added exact alignment to the Git version already published in RepoInfra.
- Added pre-publication checks for matching `git`, `git-core`, `git-core-doc`,
  and `perl-Git` builds.
- Added current Mailcow host prerequisites.
- Added `dnf download --resolve --alldeps`, signature checks, repoclosure,
  transactional publication, SELinux labeling, Apache publication, and
  run-specific rollback data.
- Validation candidate only; superseded by 1.1.1.

## 1.0.0

- Initial repository rebuild package. Rejected during validation and not
  approved for use.
