#!/usr/bin/env bash
set -euo pipefail
umask 027

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CONFIG_FILE="${SCRIPT_DIR}/infra.conf"
HOSTS_FILE="${SCRIPT_DIR}/hosts.csv"
ROLE_INPUT="${1:-}"

normalize_text_file() {
  local file="$1"
  local label="$2"
  if [[ -f "$file" ]] && grep -q $'\r' "$file" 2>/dev/null; then
    printf 'Normalizing Windows line endings in %s\n' "$label"
    if command -v dos2unix >/dev/null 2>&1; then
      dos2unix -q "$file"
    else
      sed -i 's/\r$//' "$file"
    fi
  fi
}

validate_ipv4() {
  local ip="$1"
  local IFS=.
  local octets
  read -r -a octets <<< "$ip"
  [[ ${#octets[@]} -eq 4 ]] || return 1
  local octet
  for octet in "${octets[@]}"; do
    [[ "$octet" =~ ^[0-9]+$ ]] || return 1
    (( octet >= 0 && octet <= 255 )) || return 1
  done
}

load_host_record() {
  local role="$1"
  local line
  line="$(awk -F'|' -v role="$role" '$0 !~ /^#/ && $1 == role {print; exit}' "$HOSTS_FILE")"
  [[ -n "$line" ]] || return 1
  IFS='|' read -r HOST_ROLE TARGET_HOSTNAME TARGET_IP_CIDR TARGET_GATEWAY TARGET_INTERFACE TARGET_ZONE TARGET_LABEL TARGET_NOTE <<< "$line"
  [[ -n "${TARGET_HOSTNAME}" && -n "${TARGET_IP_CIDR}" && -n "${TARGET_GATEWAY}" && -n "${TARGET_INTERFACE}" ]]
}

resolve_role_from_hostname() {
  local current
  current="$(hostnamectl --static 2>/dev/null || hostname 2>/dev/null || true)"
  [[ -n "$current" ]] || return 1
  awk -F'|' -v current="$current" '$0 !~ /^#/ && ($1 == current || $2 == current) {print $1; exit}' "$HOSTS_FILE"
}

main() {
  if [[ ${EUID} -ne 0 ]]; then
    echo "ERROR: Run as root: sudo ./verify.sh [role]" >&2
    exit 2
  fi

  [[ -r "$CONFIG_FILE" && -r "$HOSTS_FILE" ]] || {
    echo "ERROR: infra.conf and hosts.csv must be beside the script." >&2
    exit 2
  }

  normalize_text_file "$CONFIG_FILE" "infra.conf"
  normalize_text_file "$HOSTS_FILE" "hosts.csv"

  # shellcheck source=/dev/null
  source "$CONFIG_FILE"

  local role="$ROLE_INPUT"
  if [[ -z "$role" ]]; then
    role="$(resolve_role_from_hostname || true)"
  fi
  [[ -n "$role" ]] || {
    echo "ERROR: could not determine role. Pass one of: siem, internal, external." >&2
    exit 2
  }

  load_host_record "$role" || {
    echo "ERROR: no host record found for role=$role" >&2
    exit 2
  }

  RUN_ID="$(date +%Y%m%d-%H%M%S)"
  LOG_DIR="/var/log/linuxinfra"
  mkdir -p "$LOG_DIR"
  DETAIL_LOG="$LOG_DIR/${RUN_ID}-${role}-verify-detail.log"
  SUMMARY_LOG="$LOG_DIR/${RUN_ID}-${role}-verify-summary.txt"
  CURRENT_DETAIL="$SCRIPT_DIR/verify_detail.log"
  CURRENT_SUMMARY="$SCRIPT_DIR/verify_summary.log"
  : > "$DETAIL_LOG"
  : > "$SUMMARY_LOG"
  ln -sfn "$DETAIL_LOG" "$CURRENT_DETAIL"
  ln -sfn "$SUMMARY_LOG" "$CURRENT_SUMMARY"

  exec 9>>"$DETAIL_LOG"
  log_detail() { printf '[%s] %s\n' "$(date '+%F %T %z')" "$*" >&9; }

  FAILED=0
  RESULTS=()
  log_detail "Verify started role=$role hostname=$TARGET_HOSTNAME"

  run_check() {
    local label="$1"
    shift
    if "$@" >/dev/null 2>&1; then
      RESULTS+=("${label}|PASS")
      printf 'VERIFY PASS: %s\n' "$label"
    else
      RESULTS+=("${label}|FAIL")
      printf 'VERIFY FAIL: %s\n' "$label"
      FAILED=$((FAILED + 1))
    fi
  }

  echo "============================================================"
  echo "LinuxInfra Verification"
  echo "============================================================"
  echo "Role            : ${role}"
  echo "Hostname        : ${TARGET_HOSTNAME}"
  echo "IP/CIDR         : ${TARGET_IP_CIDR}"
  echo "Interface       : ${TARGET_INTERFACE}"
  echo "Gateway         : ${TARGET_GATEWAY}"
  echo "DNS             : ${DNS_PRIMARY}, ${DNS_SECONDARY}"
  echo "Timezone        : ${TIMEZONE}"
  echo "Docker user     : ${DOCKER_ADMIN_USER:-<none>}"
  echo

  run_check "hostname" test "$(hostnamectl --static)" = "$TARGET_HOSTNAME"
  run_check "interface" ip link show "$TARGET_INTERFACE"
  run_check "IPv4 address" grep -q "${TARGET_IP_CIDR%/*}" < <(ip -4 address show dev "$TARGET_INTERFACE")
  run_check "default gateway" sh -c "ip route | grep -q '^default via ${TARGET_GATEWAY}'"
  run_check "DNS primary configured" sh -c "nmcli device show '$TARGET_INTERFACE' | grep -q '${DNS_PRIMARY}'"
  run_check "timezone" test "$(timedatectl show -p Timezone --value)" = "$TIMEZONE"
  run_check "chronyd active" systemctl is-active --quiet chronyd
  run_check "firewalld active" systemctl is-active --quiet firewalld
  run_check "SELinux enforcing" test "$(getenforce)" = "Enforcing"
  run_check "docker active" systemctl is-active --quiet docker
  run_check "docker compose" docker compose version
  if [[ -n "${DOCKER_ADMIN_USER:-}" ]]; then
    run_check "docker group" id "$DOCKER_ADMIN_USER" | grep -q '\bdocker\b'
  fi
  run_check "local hostname resolution" getent hosts "$TARGET_HOSTNAME"
  run_check "hosts file entry" grep -q "$TARGET_HOSTNAME" /etc/hosts

  if [[ "$role" == "siem" ]]; then
    run_check "dns assets dir" test -d /opt/linuxinfra/dns
    run_check "dns generator script" test -x /opt/linuxinfra/dns/generate_bind_dns.sh
  fi

  {
    echo "============================================================"
    echo "LinuxInfra Verification Summary"
    echo "============================================================"
    echo "Run ID          : ${RUN_ID}"
    echo "Role            : ${role}"
    echo "Hostname        : ${TARGET_HOSTNAME}"
    echo "IP/CIDR         : ${TARGET_IP_CIDR}"
    echo "Interface       : ${TARGET_INTERFACE}"
    echo "Overall result  : $([[ $FAILED -eq 0 ]] && echo PASS || echo FAIL)"
    echo
    for item in "${RESULTS[@]}"; do
      IFS='|' read -r label result <<< "$item"
      printf '%-28s : %s\n' "$label" "$result"
    done
    echo
    echo "Detailed log    : ${DETAIL_LOG}"
    echo "Convenience link: ${CURRENT_DETAIL}"
    echo "============================================================"
  } > "$SUMMARY_LOG"

  cat "$SUMMARY_LOG"
  (( FAILED == 0 ))
}

main "$@"
