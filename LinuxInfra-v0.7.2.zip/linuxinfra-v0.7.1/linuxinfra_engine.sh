#!/usr/bin/env bash
# LinuxInfra reusable Rocky Linux 9 base build
# Menu-driven wrapper invokes this engine with role and mode.
# Usage: sudo ./linuxinfra_engine.sh <siem|internal|external> [build|dry-run]

set -uo pipefail
umask 027

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CONFIG_FILE="${SCRIPT_DIR}/infra.conf"
HOSTS_FILE="${SCRIPT_DIR}/hosts.csv"
ROLE="${1:-}"
MODE="${2:-build}"
DRY_RUN="no"
PRECHECK_RESULTS=()

if [[ "${MODE}" == "dry-run" ]]; then
  DRY_RUN="yes"
fi

if [[ ${EUID} -ne 0 ]]; then
  echo "ERROR: Run this script as root: sudo $0 <siem|internal|external> [build|dry-run]" >&2
  exit 2
fi

if [[ -z "${ROLE}" ]]; then
  echo "Usage: sudo $0 <siem|internal|external> [build|dry-run]" >&2
  exit 2
fi

if [[ ! -r "${CONFIG_FILE}" || ! -r "${HOSTS_FILE}" ]]; then
  echo "ERROR: infra.conf and hosts.csv must be beside the script." >&2
  exit 2
fi

normalize_text_file() {
  local file="$1"
  local name="$2"
  if grep -q $'\r' "$file" 2>/dev/null; then
    echo "Preflight: normalizing Windows line endings in ${name}"
    if command -v dos2unix >/dev/null 2>&1; then
      dos2unix -q "$file"
    else
      sed -i 's/\r$//' "$file"
    fi
    PRECHECK_RESULTS+=("${name}: normalized to Linux line endings")
  else
    PRECHECK_RESULTS+=("${name}: Linux line endings verified")
  fi
}

normalize_text_file "${CONFIG_FILE}" "infra.conf"
normalize_text_file "${HOSTS_FILE}" "hosts.csv"


# shellcheck source=/dev/null
source "${CONFIG_FILE}"

load_host_record() {
  local line
  line="$(awk -F'|' -v role="${ROLE}" '$0 !~ /^#/ && $1 == role {print; exit}' "${HOSTS_FILE}")"
  [[ -n "${line}" ]] || return 1
  IFS='|' read -r HOST_ROLE TARGET_HOSTNAME TARGET_IP_CIDR TARGET_GATEWAY TARGET_INTERFACE TARGET_ZONE TARGET_LABEL TARGET_NOTE <<< "${line}"
  [[ -n "${TARGET_HOSTNAME}" && -n "${TARGET_IP_CIDR}" && -n "${TARGET_GATEWAY}" && -n "${TARGET_INTERFACE}" ]]
}

load_host_record || {
  echo "ERROR: no valid host record found for role=${ROLE}" >&2
  exit 2
}
export TARGET_HOSTNAME TARGET_IP_CIDR TARGET_GATEWAY TARGET_INTERFACE TARGET_ZONE TARGET_LABEL TARGET_NOTE

RUN_ID="$(date +%Y%m%d-%H%M%S)"
LOG_DIR="/var/log/linuxinfra"
mkdir -p "${LOG_DIR}"
DETAIL_LOG="${LOG_DIR}/${RUN_ID}-${ROLE}-detail.log"
SUMMARY_LOG="${LOG_DIR}/${RUN_ID}-${ROLE}-summary.txt"
CURRENT_DETAIL="${SCRIPT_DIR}/detailed_debug.log"
CURRENT_SUMMARY="${SCRIPT_DIR}/status_summary.txt"
: > "${DETAIL_LOG}"
: > "${SUMMARY_LOG}"
ln -sfn "${DETAIL_LOG}" "${CURRENT_DETAIL}"
ln -sfn "${SUMMARY_LOG}" "${CURRENT_SUMMARY}"

START_EPOCH="$(date +%s)"
FAILED_STAGES=()
PASSED_STAGES=()
STAGE_RESULTS=()
CURRENT_STAGE=0
TOTAL_STAGES=10
if [[ "${ROLE}" == "siem" ]]; then
  TOTAL_STAGES=11
fi
if [[ "${DRY_RUN}" == "yes" ]]; then
  TOTAL_STAGES=2
fi

exec 9>>"${DETAIL_LOG}"

log_detail() {
  printf '[%s] %s\n' "$(date '+%F %T %z')" "$*" >&9
}

format_seconds() {
  local total="${1:-0}"
  printf '%02dm %02ds' "$((total / 60))" "$((total % 60))"
}

progress_bar() {
  local pct="${1:-0}" width=30 filled empty
  (( pct < 0 )) && pct=0
  (( pct > 100 )) && pct=100
  filled=$((pct * width / 100))
  empty=$((width - filled))
  printf '%*s' "${filled}" '' | tr ' ' '#'
  printf '%*s' "${empty}" '' | tr ' ' '-'
}

stage_banner() {
  local name="$1" estimate="$2"
  CURRENT_STAGE=$((CURRENT_STAGE + 1))
  local pct=$(((CURRENT_STAGE - 1) * 100 / TOTAL_STAGES))
  local elapsed=$(( $(date +%s) - START_EPOCH ))
  printf '\n[%02d/%02d] %s\n' "${CURRENT_STAGE}" "${TOTAL_STAGES}" "${name}"
  printf 'Overall: [%s] %3d%% | Elapsed: %s | Stage estimate: about %s\n' \
    "$(progress_bar "${pct}")" "${pct}" "$(format_seconds "${elapsed}")" "$(format_seconds "${estimate}")"
  log_detail "STAGE ${CURRENT_STAGE}/${TOTAL_STAGES} START: ${name}; display_estimate=${estimate}s"
}

record_result() {
  local name="$1" result="$2" note="${3:-}"
  if [[ "${result}" == "SUCCESS" ]]; then
    PASSED_STAGES+=("${name}")
  else
    FAILED_STAGES+=("${name}")
  fi
  STAGE_RESULTS+=("${name}|${result}|${note}")
  log_detail "STAGE RESULT: ${name}: ${result}: ${note}"
}

run_stage() {
  local name="$1" estimate="$2" function_name="$3"
  stage_banner "${name}" "${estimate}"
  local stage_start rc elapsed pid stage_pct overall_pct
  stage_start="$(date +%s)"

  "${function_name}" >&9 2>&1 &
  pid=$!

  while kill -0 "${pid}" 2>/dev/null; do
    elapsed=$(( $(date +%s) - stage_start ))
    if (( estimate > 0 )); then
      stage_pct=$((elapsed * 100 / estimate))
      (( stage_pct > 95 )) && stage_pct=95
    else
      stage_pct=0
    fi
    overall_pct=$(( ((CURRENT_STAGE - 1) * 100 + stage_pct) / TOTAL_STAGES ))
    printf '\rRunning: %-42s | Stage %3d%% | Overall %3d%% | Elapsed %s' \
      "${name}" "${stage_pct}" "${overall_pct}" "$(format_seconds "${elapsed}")"
    sleep 5
  done

  wait "${pid}"
  rc=$?
  elapsed=$(( $(date +%s) - stage_start ))
  printf '\r%*s\r' 140 ''

  if (( rc == 0 )); then
    printf 'Result: SUCCESS | Stage time: %s\n' "$(format_seconds "${elapsed}")"
    record_result "${name}" "SUCCESS" "completed in $(format_seconds "${elapsed}")"
  else
    printf 'Result: FAILED  | Stage time: %s | See %s\n' "$(format_seconds "${elapsed}")" "${CURRENT_DETAIL}"
    record_result "${name}" "FAILED" "exit code ${rc}; inspect detailed_debug.log"
  fi
  return 0
}

load_host_record() {
  local line
  line="$(awk -F'|' -v role="${ROLE}" '$0 !~ /^#/ && $1 == role {print; exit}' "${HOSTS_FILE}")"
  [[ -n "${line}" ]] || return 1
  IFS='|' read -r HOST_ROLE TARGET_HOSTNAME TARGET_IP_CIDR TARGET_GATEWAY TARGET_INTERFACE TARGET_ZONE TARGET_LABEL TARGET_NOTE <<< "${line}"
  [[ -n "${TARGET_HOSTNAME}" && -n "${TARGET_IP_CIDR}" && -n "${TARGET_GATEWAY}" && -n "${TARGET_INTERFACE}" ]]
}

validate_ipv4() {
  local ip="$1" IFS=. octets
  read -r -a octets <<< "${ip}"
  [[ ${#octets[@]} -eq 4 ]] || return 1
  local octet
  for octet in "${octets[@]}"; do
    [[ "${octet}" =~ ^[0-9]+$ ]] || return 1
    (( octet >= 0 && octet <= 255 )) || return 1
  done
}

stage_validate() {
  [[ -n "${TARGET_HOSTNAME:-}" ]] || { echo "TARGET_HOSTNAME is not set"; return 1; }
  [[ -n "${TARGET_IP_CIDR:-}" ]] || { echo "TARGET_IP_CIDR is not set"; return 1; }
  [[ -n "${TARGET_GATEWAY:-}" ]] || { echo "TARGET_GATEWAY is not set"; return 1; }
  [[ -n "${TARGET_INTERFACE:-}" ]] || { echo "TARGET_INTERFACE is not set"; return 1; }
  [[ -n "${PRIMARY_USER}" ]] || { echo "PRIMARY_USER is not set"; return 1; }
  [[ "${TARGET_IP_CIDR}" == */* ]] || { echo "IP must include CIDR prefix"; return 1; }
  validate_ipv4 "${TARGET_IP_CIDR%/*}" || return 1
  validate_ipv4 "${TARGET_GATEWAY}" || return 1
  validate_ipv4 "${DNS_PRIMARY}" || return 1
  validate_ipv4 "${DNS_SECONDARY}" || return 1
  [[ "${TARGET_INTERFACE}" =~ ^[a-zA-Z0-9_.:-]+$ ]] || return 1
  local os_id major
  os_id="$(. /etc/os-release && printf '%s' "${ID}")"
  [[ "${os_id}" == "rocky" ]] || { echo "This build targets Rocky Linux; found ID=${os_id}."; return 1; }
  major="$(. /etc/os-release && printf '%s' "${VERSION_ID%%.*}")"
  [[ "${major}" == "9" ]] || { echo "Rocky Linux 9 is required; found major version ${major}."; return 1; }
  ip link show "${TARGET_INTERFACE}" >/dev/null 2>&1 || {
    echo "Configured interface ${TARGET_INTERFACE} not found. Available interfaces:"
    ip -brief link
    return 1
  }
  echo "Validated role=${ROLE}, hostname=${TARGET_HOSTNAME}, interface=${TARGET_INTERFACE}, ip=${TARGET_IP_CIDR}, user=${PRIMARY_USER}"
}

stage_plan() {
  echo "Planned changes for role=${ROLE}:"
  echo "- Set hostname to ${TARGET_HOSTNAME}"
  echo "- Configure ${TARGET_INTERFACE} with ${TARGET_IP_CIDR} via gateway ${TARGET_GATEWAY}"
  echo "- Set DNS primary=${DNS_PRIMARY}, secondary=${DNS_SECONDARY}"
  echo "- Set timezone ${TIMEZONE} and NTP ${NTP_SERVER}"
  echo "- Install base packages, Docker, firewall rules, SELinux policy"
  if [[ "${ROLE}" == "siem" ]]; then
    echo "- Prepare DNS generator assets under /opt/linuxinfra/dns"
  fi
  echo "- Write summary and detailed logs"
}

stage_hostname() {
  hostnamectl set-hostname "${TARGET_HOSTNAME}"
  [[ "$(hostnamectl --static)" == "${TARGET_HOSTNAME}" ]]
}

stage_time() {
  timedatectl set-timezone "${TIMEZONE}"
  dnf -q -y install chrony
  cp -a /etc/chrony.conf "/etc/chrony.conf.linuxinfra.${RUN_ID}.bak"
  sed -i -E '/^[[:space:]]*(server|pool)[[:space:]]+/d' /etc/chrony.conf
  printf '\n# Managed by LinuxInfra\nserver %s iburst\n' "${NTP_SERVER}" >> /etc/chrony.conf
  systemctl enable --now chronyd
  systemctl restart chronyd
  chronyc tracking || true
  [[ "$(timedatectl show -p Timezone --value)" == "${TIMEZONE}" ]]
}

stage_packages() {
  if [[ "${UPDATE_OS}" == "yes" ]]; then
    dnf -q -y upgrade --refresh
  fi
  dnf -q -y install \
    NetworkManager firewalld rsyslog chrony curl wget vim-enhanced git unzip tar jq \
    bind-utils policycoreutils-python-utils dnf-plugins-core lsof tcpdump
  systemctl enable --now NetworkManager firewalld rsyslog
}

stage_network() {
  if [[ "${APPLY_NETWORK}" != "yes" ]]; then
    echo "Network changes disabled by APPLY_NETWORK=${APPLY_NETWORK}"
    return 0
  fi

  local conn
  conn="$(nmcli -g GENERAL.CONNECTION device show "${TARGET_INTERFACE}" | head -n1)"
  if [[ -z "${conn}" || "${conn}" == "--" ]]; then
    conn="linuxinfra-${TARGET_INTERFACE}"
    nmcli connection add type ethernet ifname "${TARGET_INTERFACE}" con-name "${conn}"
  fi

  nmcli connection modify "${conn}" \
    connection.interface-name "${TARGET_INTERFACE}" \
    connection.autoconnect yes \
    connection.zone public \
    ipv4.method manual \
    ipv4.addresses "${TARGET_IP_CIDR}" \
    ipv4.gateway "${TARGET_GATEWAY}" \
    ipv4.dns "${DNS_PRIMARY},${DNS_SECONDARY}" \
    ipv4.ignore-auto-dns yes

  nmcli connection up "${conn}"
  nmcli device show "${TARGET_INTERFACE}"
  ip -brief address show "${TARGET_INTERFACE}"
  ip route
  grep -q "${TARGET_IP_CIDR%/*}" < <(ip -4 address show dev "${TARGET_INTERFACE}")
}

stage_hosts() {
  local begin='# BEGIN LINUXINFRA MANAGED HOSTS'
  local end='# END LINUXINFRA MANAGED HOSTS'
  local tmp
  tmp="$(mktemp)"
  awk -v begin="${begin}" -v end="${end}" '
    $0 == begin {skip=1; next}
    $0 == end {skip=0; next}
    !skip {print}
  ' /etc/hosts > "${tmp}"

  {
    cat "${tmp}"
    printf '\n%s\n' "${begin}"
    awk -F'|' '$0 !~ /^#/ && NF >= 5 {
      split($3, addr, "/");
      printf "%-15s %-35s %s\n", addr[1], $2, $1
    }' "${HOSTS_FILE}"
    printf '%s\n' "${end}"
  } > /etc/hosts
  rm -f "${tmp}"
  getent hosts "${TARGET_HOSTNAME}"
}

firewall_add_port() {
  local port="$1"
  firewall-cmd --permanent --zone=public --add-port="${port}"
}

stage_firewall() {
  if [[ "${CONFIGURE_FIREWALL}" != "yes" ]]; then
    echo "Firewall configuration disabled by CONFIGURE_FIREWALL=${CONFIGURE_FIREWALL}"
    return 0
  fi

  systemctl enable --now firewalld
  firewall-cmd --set-default-zone=public
  firewall-cmd --permanent --zone=public --change-interface="${TARGET_INTERFACE}"
  firewall-cmd --permanent --zone=public --add-service=ssh

  local ports=()
  case "${ROLE}" in
    siem)
      ports=(53/tcp 53/udp 514/tcp 514/udp 12201/tcp 12201/udp 9000/tcp)
      ;;
    internal|external)
      ports=(25/tcp 80/tcp 110/tcp 143/tcp 443/tcp 465/tcp 587/tcp 993/tcp 995/tcp 4190/tcp)
      ;;
    repo)
      ports=(22/tcp 80/tcp 443/tcp 5000/tcp)
      ;;
    proxy)
      ports=(22/tcp 3128/tcp 80/tcp 443/tcp)
      ;;
    cloud)
      ports=(22/tcp 443/tcp 8443/tcp)
      ;;
    *)
      echo "Unknown firewall role ${ROLE}"
      return 1
      ;;
  esac

  local port
  for port in "${ports[@]}"; do
    firewall_add_port "${port}"
  done
  firewall-cmd --reload
  firewall-cmd --zone=public --list-all

  mkdir -p /etc/linuxinfra
  {
    echo "role=${ROLE}"
    echo "interface=${TARGET_INTERFACE}"
    echo "zone=public"
    echo "inbound_services=ssh"
    printf 'inbound_ports=%s\n' "${ports[*]}"
    echo "outbound_policy=not_restricted_in_base_build"
  } > /etc/linuxinfra/firewall-manifest.conf
}

stage_selinux() {
  if [[ "${ENFORCE_SELINUX}" != "yes" ]]; then
    echo "SELinux enforcement disabled by configuration. Current: $(getenforce)"
    return 0
  fi
  sed -i -E 's/^SELINUX=.*/SELINUX=enforcing/' /etc/selinux/config
  setenforce 1
  [[ "$(getenforce)" == "Enforcing" ]]
}

stage_docker() {
  if [[ "${INSTALL_DOCKER}" != "yes" ]]; then
    echo "Docker installation disabled by INSTALL_DOCKER=${INSTALL_DOCKER}"
    return 0
  fi

  dnf -q -y remove docker docker-client docker-client-latest docker-common docker-latest \
    docker-latest-logrotate docker-logrotate docker-engine podman-docker || true
  dnf config-manager --add-repo https://download.docker.com/linux/centos/docker-ce.repo
  dnf -q -y install docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
  systemctl enable --now docker

  if [[ -n "${DOCKER_ADMIN_USER}" ]]; then
    id "${DOCKER_ADMIN_USER}" >/dev/null 2>&1 || {
      echo "DOCKER_ADMIN_USER ${DOCKER_ADMIN_USER} does not exist"
      return 1
    }
    usermod -aG docker "${DOCKER_ADMIN_USER}"
  fi

  docker version
  docker compose version
}

stage_dns_assets() {
  if [[ "${ROLE}" != "siem" ]]; then
    echo "DNS asset preparation skipped for role=${ROLE}"
    return 0
  fi

  local dns_dir="/opt/linuxinfra/dns"
  local output_dir="${dns_dir}/output"
  mkdir -p "${output_dir}"

  cp -f "${HOSTS_FILE}" "${dns_dir}/hosts.csv"

  cat > "${dns_dir}/dns_profile.conf" <<EOF_DNS
# DNS build profile for later execution
PROJECT_NAME=${PROJECT_NAME}
ROLE=${ROLE}
PRIMARY_DNS=${DNS_PRIMARY}
SECONDARY_DNS=${DNS_SECONDARY}
TIMEZONE=${TIMEZONE}
NTP_SERVER=${NTP_SERVER}
HOSTS_FILE=${dns_dir}/hosts.csv
OUTPUT_DIR=${output_dir}
EOF_DNS

  cat > "${dns_dir}/generate_bind_dns.sh" <<'EOF_GEN'
#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROFILE_FILE="${SCRIPT_DIR}/dns_profile.conf"
HOSTS_FILE="${SCRIPT_DIR}/hosts.csv"
OUTPUT_DIR="${SCRIPT_DIR}/output"

if [[ ! -r "${PROFILE_FILE}" || ! -r "${HOSTS_FILE}" ]]; then
  echo "dns_profile.conf and hosts.csv must be present beside this script." >&2
  exit 1
fi

# shellcheck source=/dev/null
source "${PROFILE_FILE}"
mkdir -p "${OUTPUT_DIR}"

serial="$(date +%Y%m%d%H)"

cat > "${OUTPUT_DIR}/README.txt" <<EOF2
This directory is a generator output area.
Run this script again after updating hosts.csv.
EOF2

declare -A zones_seen=()
declare -A host_zone=()

: > "${OUTPUT_DIR}/records.tmp"
while IFS='|' read -r role hostname ip_cidr gateway iface zone_name host_label note; do
  [[ -z "${role}" || "${role}" =~ ^# ]] && continue
  ip="${ip_cidr%/*}"
  host_zone["${hostname}"]="${zone_name}"
  zones_seen["${zone_name}"]=1
  printf '%s|%s|%s|%s\n' "${role}" "${hostname}" "${ip}" "${host_label:-@}" >> "${OUTPUT_DIR}/records.tmp"
done < "${HOSTS_FILE}"

rm -f "${OUTPUT_DIR}"/db.*
for zone in "${!zones_seen[@]}"; do
  {
    cat <<Z2
$TTL 86400
@ IN SOA ns1.${zone}. admin.${zone}. (
  ${serial}
  3600
  900
  604800
  86400 )
@ IN NS ns1.${zone}.
@ IN TXT "v=spf1 mx -all"
Z2
    while IFS='|' read -r role hostname ip label; do
      [[ -z "${role}" ]] && continue
      host_zone_name="${host_zone[${hostname}]:-}"
      [[ "${host_zone_name}" == "${zone}" ]] || continue
      if [[ "${label}" == "@" || -z "${label}" ]]; then
        echo "@ IN A ${ip}"
        if [[ "${role}" != "siem" ]]; then
          echo "@ IN MX 10 ${hostname}."
        fi
      else
        echo "${label} IN A ${ip}"
      fi
    done < <(awk -F'|' '$0 !~ /^#/ && NF >= 4 {print}' "${OUTPUT_DIR}/records.tmp")
  } > "${OUTPUT_DIR}/db.${zone}"
done

{
  echo "$TTL 86400"
  echo "@ IN SOA ns1.10.168.192.in-addr.arpa. admin.10.168.192.in-addr.arpa. ("
  echo "  ${serial}"
  echo "  3600"
  echo "  900"
  echo "  604800"
  echo "  86400 )"
  echo "@ IN NS ns1.10.168.192.in-addr.arpa."
  while IFS='|' read -r role hostname ip label; do
    [[ -z "${role}" ]] && continue
    IFS=. read -r o1 o2 o3 o4 <<< "${ip}"
    echo "${o4} IN PTR ${hostname}."
  done < <(awk -F'|' '$0 !~ /^#/ && NF >= 4 {print}' "${OUTPUT_DIR}/records.tmp")
} > "${OUTPUT_DIR}/db.192.168.10.rev"

rm -f "${OUTPUT_DIR}/records.tmp"

echo "Generated DNS zone files in ${OUTPUT_DIR}"
EOF_GEN

  chmod 0750 "${dns_dir}/generate_bind_dns.sh"
  echo "Prepared DNS generator assets in ${dns_dir}"
}

check_item() {
  local label="$1"
  shift
  if "$@" >/dev/null 2>&1; then
    printf 'VERIFY PASS: %s\n' "${label}"
    return 0
  fi
  printf 'VERIFY FAIL: %s\n' "${label}"
  return 1
}


stage_verify() {
  local verify_script="${SCRIPT_DIR}/verify.sh"
  if [[ ! -x "${verify_script}" ]]; then
    echo "verify.sh not found or not executable: ${verify_script}"
    return 1
  fi
  "${verify_script}" "${ROLE}"
}

write_summary() {
  local end_epoch elapsed overall
  end_epoch="$(date +%s)"
  elapsed=$((end_epoch - START_EPOCH))
  if (( ${#FAILED_STAGES[@]} == 0 )); then
    overall="SUCCESS"
  else
    overall="FAILED"
  fi

  {
    echo "============================================================"
    echo "${PROJECT_NAME} Base Infrastructure Build Summary"
    echo "============================================================"
    echo "Run ID          : ${RUN_ID}"
    echo "Version         : ${PROJECT_VERSION}"
    echo "Environment     : ${ENVIRONMENT}"
    echo "Role            : ${ROLE}"
    echo "Hostname        : ${TARGET_HOSTNAME:-unknown}"
    echo "IP/CIDR         : ${TARGET_IP_CIDR:-unknown}"
    echo "Interface       : ${TARGET_INTERFACE:-unknown}"
    echo "Gateway         : ${TARGET_GATEWAY:-unknown}"
    echo "DNS             : ${DNS_PRIMARY}, ${DNS_SECONDARY}"
    echo "Timezone        : ${TIMEZONE}"
    echo "NTP             : ${NTP_SERVER}"
    echo "Primary user    : ${PRIMARY_USER}"
    echo "Docker admin    : ${DOCKER_ADMIN_USER:-<none>}"
    echo "Overall result  : ${overall}"
    echo "Elapsed time    : $(format_seconds "${elapsed}")"
    echo
    echo "Preflight file format"
    echo "------------------------------------------------------------"
    local item
    for item in "${PRECHECK_RESULTS[@]}"; do
      echo "- ${item}"
    done
    echo
    echo "Stage results"
    echo "------------------------------------------------------------"
    local name result note
    for item in "${STAGE_RESULTS[@]}"; do
      IFS='|' read -r name result note <<< "${item}"
      printf '%-34s : %-7s | %s\n' "${name}" "${result}" "${note}"
    done
    echo
    if (( ${#FAILED_STAGES[@]} > 0 )); then
      echo "Failed stages requiring review"
      echo "------------------------------------------------------------"
      local failed
      for failed in "${FAILED_STAGES[@]}"; do
        echo "- ${failed}"
      done
      echo
      echo "Review the detailed log: ${DETAIL_LOG}"
      echo "Convenience link       : ${CURRENT_DETAIL}"
    else
      echo "No failed stages were recorded."
    fi
    echo
    if [[ -f /etc/linuxinfra/firewall-manifest.conf ]]; then
      echo "Firewall manifest"
      echo "------------------------------------------------------------"
      cat /etc/linuxinfra/firewall-manifest.conf
    fi
    if [[ "${ROLE}" == "siem" && -d /opt/linuxinfra/dns ]]; then
      echo
      echo "DNS generator assets"
      echo "------------------------------------------------------------"
      echo "/opt/linuxinfra/dns/generate_bind_dns.sh"
      echo "/opt/linuxinfra/dns/dns_profile.conf"
      echo "/opt/linuxinfra/dns/hosts.csv"
      echo "/opt/linuxinfra/dns/output/"
    fi
    if [[ "${DRY_RUN}" == "yes" ]]; then
      echo
      echo "Mode"
      echo "------------------------------------------------------------"
      echo "DRY RUN / VALIDATE ONLY"
    fi
    echo "============================================================"
  } > "${SUMMARY_LOG}"

  local pct=100
  printf '\nOverall: [%s] %3d%% | Total elapsed: %s\n' \
    "$(progress_bar "${pct}")" "${pct}" "$(format_seconds "${elapsed}")"
  cat "${SUMMARY_LOG}"
}

log_detail "LinuxInfra build started: role=${ROLE}; mode=${MODE}; run_id=${RUN_ID}; script_dir=${SCRIPT_DIR}"
for item in "${PRECHECK_RESULTS[@]}"; do
  log_detail "PRECHECK: ${item}"
done

echo "============================================================"
echo "${PROJECT_NAME} Build Framework"
echo "============================================================"
echo "Role           : ${ROLE}"
echo "Hostname       : ${TARGET_HOSTNAME:-pending}"
echo "IP/CIDR        : ${TARGET_IP_CIDR:-pending}"
echo "Interface      : ${TARGET_INTERFACE:-pending}"
echo "Primary user   : ${PRIMARY_USER:-pending}"
echo "Estimated time : ~${EST_VALIDATE:-10}m total (display estimate)"
echo "Logs           : ${SUMMARY_LOG}"
echo "               : ${DETAIL_LOG}"
echo "============================================================"

run_stage "Validate configuration and host inventory" "${EST_VALIDATE}" stage_validate
if (( ${#FAILED_STAGES[@]} > 0 )); then
  write_summary
  exit 1
fi

if [[ "${DRY_RUN}" == "yes" ]]; then
  run_stage "Plan changes without making edits" "${EST_PLAN}" stage_plan
  write_summary
  exit 0
fi

run_stage "Set system hostname" "${EST_HOSTNAME}" stage_hostname
run_stage "Configure timezone and NTP" "${EST_TIME}" stage_time
run_stage "Update OS and install base packages" "${EST_PACKAGES}" stage_packages
run_stage "Configure static network and DNS" "${EST_NETWORK}" stage_network
run_stage "Synchronize managed hosts entries" "${EST_HOSTS}" stage_hosts
run_stage "Apply role-based inbound firewall rules" "${EST_FIREWALL}" stage_firewall
run_stage "Enforce SELinux policy" "${EST_SELINUX}" stage_selinux
run_stage "Install and start Docker Engine" "${EST_DOCKER}" stage_docker
if [[ "${ROLE}" == "siem" ]]; then
  run_stage "Prepare DNS generator assets" "${EST_BIND}" stage_dns_assets
fi
run_stage "Verify base infrastructure" "${EST_VERIFY}" stage_verify

write_summary

if (( ${#FAILED_STAGES[@]} > 0 )); then
  exit 1
fi
exit 0
