#!/usr/bin/env bash
set -Eeuo pipefail

APP_NAME="annex-repo-fix"
REPO_ROOT="/srv/repo/rpms"
TARGET_SUBDIR="mailcow-fix"
BASE_LOG_DIR="/var/log/repoinfra/mailcow-annex-fix"
TS="$(date +%Y%m%d-%H%M%S)"
RUN_DIR="${BASE_LOG_DIR}/${TS}"
LOG_FILE="${RUN_DIR}/detail.log"
WORK_DIR="${REPO_ROOT}/${TARGET_SUBDIR}/${TS}"
MISSING_FILE="${RUN_DIR}/missing-deps.txt"
REPORT_FILE="${RUN_DIR}/report.txt"
PLAN_FILE="${RUN_DIR}/plan.txt"

PASS_COUNT=0
WARN_COUNT=0
FAIL_COUNT=0
START_EPOCH="$(date +%s)"

log() {
  local level="$1"
  shift
  printf '[%s] %s\n' "$level" "$*"
}

info() { log INFO "$*"; }
pass() { PASS_COUNT=$((PASS_COUNT + 1)); log PASS "$*"; }
warn() { WARN_COUNT=$((WARN_COUNT + 1)); log WARN "$*"; }
fail() { FAIL_COUNT=$((FAIL_COUNT + 1)); log FAIL "$*"; }
phase() { printf '\n========== %s ==========%s' "$*" $'\n'; }
step() { log STEP "$*"; }

cleanup_on_err() {
  local exit_code=$?
  fail "Script stopped unexpectedly at line ${BASH_LINENO[0]}: ${BASH_COMMAND}"
  info "Exit code: ${exit_code}"
  info "See log: ${LOG_FILE}"
  exit "$exit_code"
}

on_interrupt() {
  fail "Interrupted by user"
  info "See log: ${LOG_FILE}"
  exit 130
}

trap cleanup_on_err ERR
trap on_interrupt INT
trap on_interrupt TERM

mkdir -p "$RUN_DIR" "$WORK_DIR"
exec > >(tee -a "$LOG_FILE") 2>&1

print_header() {
  printf '\n%s\n' "------------------------------------------------------------"
  printf '%s\n' "Mailcow Repo Annex Repair Package"
  printf '%s\n' "Purpose: repair missing git dependency closure on Repo VM"
  printf '%s\n' "Mode: phase-by-phase status with log, report, and missing-deps output"
  printf '%s\n' "Log: $LOG_FILE"
  printf '%s\n' "Work dir: $WORK_DIR"
  printf '%s\n' "------------------------------------------------------------\n"
}

require_root() {
  if [[ ${EUID} -ne 0 ]]; then
    fail "Run this package as root: sudo bash ./annex-repo-fix.sh"
    exit 1
  fi
}

check_tools() {
  phase "1) Preflight checks"
  local required=(dnf createrepo_c restorecon systemctl find awk sed grep sort)
  local missing=()
  for tool in "${required[@]}"; do
    if ! command -v "$tool" >/dev/null 2>&1; then
      missing+=("$tool")
    fi
  done

  if (( ${#missing[@]} > 0 )); then
    warn "Missing tools: ${missing[*]}"
    step "Trying to install required repo tooling"
    if dnf install -y dnf-plugins-core createrepo_c; then
      pass "Installed repo tooling"
    else
      fail "Could not install dnf-plugins-core and createrepo_c"
      exit 1
    fi
  else
    pass "Required tools are present"
  fi

  if ! command -v dnf >/dev/null 2>&1; then
    fail "dnf is not available"
    exit 1
  fi
}

show_repo_state() {
  phase "2) Current repo state"
  step "Enabled repos"
  dnf repolist --enabled || true

  step "git availability"
  dnf list available 'git*' || true

  step "git dependency requirements"
  dnf repoquery --requires git | sort -u || true
}

find_repo_files() {
  phase "3) Current repo file presence"
  if [[ -d "$REPO_ROOT" ]]; then
    step "Searching for existing git and perl RPMs under $REPO_ROOT"
    {
      find "$REPO_ROOT" -name 'git*.rpm' -o -name 'perl*.rpm' | sort
    } | tee "$REPORT_FILE"
    pass "Repo file scan completed"
  else
    fail "Repo root not found: $REPO_ROOT"
    exit 1
  fi
}

attempt_download() {
  local pkg="$1"
  step "Attempting to download package and dependencies: $pkg"
  if dnf download --resolve --destdir "$WORK_DIR" "$pkg"; then
    pass "Downloaded: $pkg"
    return 0
  fi
  warn "Could not download: $pkg"
  return 1
}

copy_downloaded_rpms() {
  phase "4) Download and collect RPMs"
  step "Creating work directory: $WORK_DIR"
  mkdir -p "$WORK_DIR"

  local targets=(git git-core git-core-doc perl-Git perl-Term-ReadKey perl-libs)
  local downloaded_any=0
  local t
  for t in "${targets[@]}"; do
    if attempt_download "$t"; then
      downloaded_any=1
    fi
  done

  if [[ $downloaded_any -eq 0 ]]; then
    fail "No target package could be downloaded from the enabled repos"
    return 1
  fi

  step "Copying downloaded RPMs into repo tree"
  shopt -s nullglob
  local rpms=("$WORK_DIR"/*.rpm)
  if (( ${#rpms[@]} == 0 )); then
    fail "No RPMs were downloaded into $WORK_DIR"
    return 1
  fi

  mkdir -p "$REPO_ROOT/$TARGET_SUBDIR"
  cp -av "${rpms[@]}" "$REPO_ROOT/$TARGET_SUBDIR/"
  pass "Copied ${#rpms[@]} RPM(s) into $REPO_ROOT/$TARGET_SUBDIR"
}

build_missing_plan() {
  phase "5) Dependency verification"
  local req_file="$RUN_DIR/git-requires.txt"
  local have_file="$RUN_DIR/git-present.txt"

  dnf repoquery --requires git | sort -u > "$req_file" || true
  find "$REPO_ROOT" -name '*.rpm' | sed 's#.*/##' | sort -u > "$have_file" || true

  info "Building a missing dependency plan for git"
  local missing=()
  while IFS= read -r dep; do
    [[ -z "$dep" ]] && continue
    case "$dep" in
      /usr/bin/*|/bin/*|perl\(*|python\(*|sh|/usr/bin/sh|/bin/sh)
        continue
        ;;
      git-core*|git-core-doc*|perl-Git*|perl-Term-ReadKey*|perl-libs*)
        if ! grep -Eq "^${dep//./\.}" "$have_file"; then
          missing+=("$dep")
        fi
        ;;
    esac
  done < "$req_file"

  printf '%s\n' "${missing[@]:-}" | sed '/^$/d' > "$PLAN_FILE"

  if (( ${#missing[@]} > 0 )); then
    printf '%s\n' "${missing[@]}" > "$MISSING_FILE"
    warn "Still missing ${#missing[@]} dependency item(s)"
    printf ' - %s\n' "${missing[@]}"
    return 1
  else
    : > "$MISSING_FILE"
    : > "$PLAN_FILE"
    pass "No missing git-related dependency packages were detected"
    return 0
  fi
}

refresh_repo_metadata() {
  phase "6) Repo refresh"
  step "Rebuilding metadata for $REPO_ROOT"
  createrepo_c --update "$REPO_ROOT"
  pass "createrepo_c completed"

  step "Restoring SELinux contexts"
  restorecon -Rv /srv/repo || true
  pass "SELinux contexts restored"

  step "Restarting Apache"
  systemctl restart httpd
  pass "Apache restarted"
}

summary() {
  phase "7) Summary"
  local end_epoch elapsed
  end_epoch="$(date +%s)"
  elapsed=$((end_epoch - START_EPOCH))

  printf 'Status counts:\n'
  printf '  PASS : %d\n' "$PASS_COUNT"
  printf '  WARN : %d\n' "$WARN_COUNT"
  printf '  FAIL : %d\n' "$FAIL_COUNT"
  printf 'Elapsed: %s seconds\n' "$elapsed"
  printf 'Log    : %s\n' "$LOG_FILE"
  printf 'Report : %s\n' "$REPORT_FILE"
  printf 'Plan   : %s\n' "$PLAN_FILE"
  printf 'Missing: %s\n' "$MISSING_FILE"

  if [[ -s "$MISSING_FILE" ]]; then
    warn "Missing dependency items remain. Review $MISSING_FILE"
  else
    pass "No missing dependency items recorded"
  fi

  printf '\nNext client refresh steps:\n'
  printf '  sudo dnf clean all\n'
  printf '  sudo dnf makecache\n'
  printf '  sudo dnf install -y git\n'
}

main() {
  print_header
  require_root
  check_tools
  show_repo_state
  find_repo_files
  copy_downloaded_rpms
  build_missing_plan || true
  refresh_repo_metadata
  summary
}

main "$@"
