Mailcow Repo Annex Repair Package

What it does:
- Shows a banner and phase-by-phase status.
- Checks repo VM prerequisites.
- Inspects the current git dependency chain.
- Tries to download:
  git, git-core, git-core-doc, perl-Git, perl-Term-ReadKey, perl-libs
- Copies any downloaded RPMs into /srv/repo/rpms/mailcow-fix/<timestamp>/
- Rebuilds repodata.
- Restores SELinux contexts.
- Restarts httpd.
- Writes a detailed log under:
  /var/log/repoinfra/mailcow-annex-fix/<timestamp>/detail.log

How to run:
  chmod +x annex-repo-fix.sh
  sudo bash ./annex-repo-fix.sh

What to check after it runs:
- /var/log/repoinfra/mailcow-annex-fix/<timestamp>/detail.log
- /var/log/repoinfra/mailcow-annex-fix/<timestamp>/missing-deps.txt
- /srv/repo/rpms/mailcow-fix/<timestamp>/
