Mailcow Repo Annex Repair Package

What this package does:
- Checks required tools on the Repo VM
- Shows current enabled repos and git dependency requirements
- Attempts to download git with dependency resolution
- Copies downloaded RPMs into /srv/repo/rpms/mailcow-fix/<timestamp>
- Rebuilds repo metadata with createrepo_c
- Restores SELinux context on /srv/repo
- Restarts Apache
- Writes a detailed log under /var/log/repoinfra/mailcow-annex-fix/<timestamp>/detail.log

How to run:
  sudo bash ./annex-repo-fix.sh

How to review results:
  cat /var/log/repoinfra/mailcow-annex-fix/<timestamp>/detail.log
  cat /var/log/repoinfra/mailcow-annex-fix/<timestamp>/missing-deps.txt

Notes:
- This package can only resolve packages that exist in the enabled repos on the Repo VM.
- If the source repos do not contain the missing git dependency chain, the script will report the gaps clearly.
